<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\GoodweData>
 */
class GoodweDataFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'P' => $this->faker->randomFloat(2, 0, 100), // Nilai P antara 0 dan 100 dengan 2 desimal
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}
