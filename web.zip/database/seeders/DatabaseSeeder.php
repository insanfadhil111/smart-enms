<?php

namespace Database\Seeders;

use App\Models\GoodweData;
use Illuminate\Database\Seeder;
use Database\Seeders\UserSeeder;
use Illuminate\Support\Facades\DB;
use Database\Seeders\MdpDataSeeder;
use Database\Seeders\IkeStandarSeeder;
use Database\Seeders\MdpControlSeeder;
use Database\Seeders\EnvironmentDataSeeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        DB::table('energy_costs')->insert([
            'harga' => '1440',
            'pokok' => '1440',
            'delay' => '300',
        ]);

        $this->call([
            EnvironmentDataSeeder::class,
            GoodweDataSeeder::class,
            IkeStandarSeeder::class,
            MdpControlSeeder::class,
            MdpDataSeeder::class,
            MdpKwhSeeder::class,
            MppDataSeeder::class,
            UserSeeder::class,
        ]);
    }
}
