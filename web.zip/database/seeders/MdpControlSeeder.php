<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\MdpControl;

class MdpControlSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $devices = [
            ['device' => 'Device 1', 'status' => 0],
            ['device' => 'Device 2', 'status' => 0],
            ['device' => 'Device 3', 'status' => 0],
            ['device' => 'Device 4', 'status' => 0],
        ];

        foreach ($devices as $device) {
            MdpControl::create($device);
        }
    }
}
