<?php

namespace Database\Seeders;

use App\Models\IkeStandar;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class IkeStandarSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $values = [
            ['total_energy' => 350, 'created_at' => '2023-01-31 23:50:00', 'updated_at' => '2023-01-31 23:50:00'],
            ['total_energy' => 350, 'created_at' => '2023-02-28 23:50:00', 'updated_at' => '2023-02-28 23:50:00'],
            ['total_energy' => 350, 'created_at' => '2023-03-31 23:50:00', 'updated_at' => '2023-03-31 23:50:00'],
            ['total_energy' => 350, 'created_at' => '2023-04-30 23:50:00', 'updated_at' => '2023-04-30 23:50:00'], // April has 30 days
            ['total_energy' => 350, 'created_at' => '2023-05-31 23:50:00', 'updated_at' => '2023-05-31 23:50:00'],
            ['total_energy' => 350, 'created_at' => '2023-06-30 23:50:00', 'updated_at' => '2023-06-30 23:50:00'], // June has 30 days
            ['total_energy' => 350, 'created_at' => '2023-07-31 23:50:00', 'updated_at' => '2023-07-31 23:50:00'],
            ['total_energy' => 350, 'created_at' => '2023-08-31 23:50:00', 'updated_at' => '2023-08-31 23:50:00'],
            ['total_energy' => 350, 'created_at' => '2023-09-30 23:50:00', 'updated_at' => '2023-09-30 23:50:00'], // September has 30 days
            ['total_energy' => 350, 'created_at' => '2023-10-31 23:50:00', 'updated_at' => '2023-10-31 23:50:00'],
            ['total_energy' => 350, 'created_at' => '2023-11-30 23:50:00', 'updated_at' => '2023-11-30 23:50:00'], // November has 30 days
            ['total_energy' => 350, 'created_at' => '2023-12-31 23:50:00', 'updated_at' => '2023-12-31 23:50:00'],
            ['total_energy' => 350, 'created_at' => '2024-01-31 23:50:00', 'updated_at' => '2024-01-31 23:50:00'],
            ['total_energy' => 350, 'created_at' => '2024-02-29 23:50:00', 'updated_at' => '2024-02-29 23:50:00'], // Leap year in 2024
            ['total_energy' => 350, 'created_at' => '2024-03-31 23:50:00', 'updated_at' => '2024-03-31 23:50:00'],
        ];


        foreach ($values as $value) {
            IkeStandar::create($value);
        }
    }
}
