<footer class="footer pt-3  ">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="copyright text-center text-sm text-muted">
                ©
                <script>
                    document.write(new Date().getFullYear())
                </script>,
                made with <i class="fa fa-heart"></i> by
                <a href="https://iotlab-uns.com" class="font-weight-bold" target="_blank">IoT Lab UNS</a>
            </div>
        </div>
    </div>
</footer>