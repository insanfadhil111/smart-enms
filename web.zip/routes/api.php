<?php

use App\Http\Controllers\EnergyController;
use App\Http\Controllers\MdpController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// MDP
Route::post('add-mdpdata/{id}', [MdpController::class, 'addMdpData']);
Route::get('get-mdpdata', [MdpController::class, 'getMdpData']);
Route::get('get-mdpdata/{id}', [MdpController::class, 'getMdpDataById']);
Route::get('get-mdpdata/{id}/{limit}', [MdpController::class, 'getMdpDataByIdLimit']);
Route::post('add-mdpkwh/{id}', [MdpController::class, 'addMdpKwh']);
Route::get('get-mdpkwh', [MdpController::class, 'getMdpKwh']);
Route::get('get-mdpkwh/{id}', [MdpController::class, 'getMdpKwhById']);
Route::get('get-mdpkwh/{id}/{limit}', [MdpController::class, 'getMdpKwhByIdLimit']);

Route::post('add-syahrul/{id}', [MdpController::class, 'addSyahrul']);

// MPP



// Other Energy Stuff
Route::get('total-energy', [EnergyController::class, 'getTotalEnergy']);
Route::post('total-energy', [EnergyController::class, 'addTotalEnergy']);
Route::get('daily-energy', [EnergyController::class, 'getDailyEnergy']);
Route::get('daily-energy-reversed', [EnergyController::class, 'getDailyEnergyReversed']);
Route::get('monthly-energy', [EnergyController::class, 'getMonthlyEnergy']);
Route::get('annual-energy', [EnergyController::class, 'getAnnualEnergy']);
Route::get('ike-dummy', [EnergyController::class, 'getIkeDummy']);
Route::get('ike-dummy-annual', [EnergyController::class, 'getIkeDummyAnnual']);
Route::post('receive-forecast', [EnergyController::class, 'receiveForecast']);
Route::get('weekly-prediction', [EnergyController::class, 'getWeeklyPrediction']);


Route::get('ApiEnergy', [EnergyController::class, 'getAllEnergies']);
Route::post('ApiEnergy', [EnergyController::class, 'addEnergiesData']);
Route::get('ApiEnergy/{id}', [EnergyController::class, 'getEnergies']);

Route::get('debug-func', [EnergyController::class, 'debugFunc']);


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
