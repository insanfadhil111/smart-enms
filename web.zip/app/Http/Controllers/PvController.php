<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\MppData;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\GoodweData;

class PvController extends Controller
{
    public function mppTodayGeneration()
    {
        $today = Carbon::today();

        // Retrieve today's data ordered by time
        $dataPoints = MppData::whereDate('created_at', $today)
            ->orderBy('created_at')
            ->get();

        $totalEnergy = 0;
        $previousTimestamp = null;

        foreach ($dataPoints as $data) {
            if ($previousTimestamp) {
                // Calculate the time difference in hours
                $timeDifference = $previousTimestamp->diffInMinutes($data->created_at) / 60;

                // Calculate energy contribution for this interval
                $energyContribution = $data->P * $timeDifference;
                $totalEnergy += $energyContribution;
            }
            // Update the previous timestamp
            $previousTimestamp = $data->created_at;
        }
        return $totalEnergy / 1000;
    }

    public function gwTodayGeneration()
    {
        $today = Carbon::today();

        // Retrieve today's data ordered by time
        $dataPoints = GoodweData::whereDate('created_at', $today)
            ->orderBy('created_at')
            ->get();

        $totalEnergy = 0;
        $previousTimestamp = null;

        foreach ($dataPoints as $data) {
            if ($previousTimestamp) {
                // Calculate the time difference in hours
                $timeDifference = $previousTimestamp->diffInMinutes($data->created_at) / 60;

                // Calculate energy contribution for this interval
                $energyContribution = $data->P * $timeDifference;
                $totalEnergy += $energyContribution;
            }
            // Update the previous timestamp
            $previousTimestamp = $data->created_at;
        }
        return $totalEnergy / 1000;
    }
}
