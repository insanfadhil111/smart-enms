<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\MdpKwh;
use App\Models\MdpData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class MdpController extends Controller
{
    /* 
        for Pages
    */


    /* 
        for API
    */
    public function addMdpData(Request $request, $id)
    {
        /**
         * Save MdpData if the latest data was created more than 5 minutes ago.
         *
         * @param  \Illuminate\Http\Request  $request
         * @param  int  $id
         * @return \Illuminate\Http\JsonResponse
         */
        $latestData = MdpData::where('id_kwh', $id)->latest()->first();
        if ($latestData) {
            $fiveMinutesAgo = now()->subMinutes(5);
            if ($latestData->created_at->$fiveMinutesAgo) {
                $mdp = new MdpData;

                $mdp->id_kwh = $request->$id;
                $mdp->Van = $request->Van;
                $mdp->Vbn = $request->Vbn;
                $mdp->Vcn = $request->Vcn;
                $mdp->Ia = $request->Ia;
                $mdp->Ib = $request->Ib;
                $mdp->Ic = $request->Ic;
                $mdp->It = $request->It;
                $mdp->Pa = $request->Pa;
                $mdp->Pb = $request->Pb;
                $mdp->Pc = $request->Pc;
                $mdp->Pt = $request->Pt;
                $mdp->Qa = $request->Qa;
                $mdp->Qb = $request->Qb;
                $mdp->Qc = $request->Qc;
                $mdp->Qt = $request->Qt;
                $mdp->pf = $request->pf;
                $mdp->f = $request->f;
                $mdp->save();

                return response()->json([
                    "message" => "Data already saved"
                ], 201);
            } else {
                return response()->json([
                    "message" => "Sorry, belum 5 menit"
                ], 400);
            }
        } else {
            // Save kalau belum ada data
            $mdp = new MdpData;

            $mdp->id_kwh = $request->$id;
            $mdp->Van = $request->Van;
            $mdp->Vbn = $request->Vbn;
            $mdp->Vcn = $request->Vcn;
            $mdp->Ia = $request->Ia;
            $mdp->Ib = $request->Ib;
            $mdp->Ic = $request->Ic;
            $mdp->It = $request->It;
            $mdp->Pa = $request->Pa;
            $mdp->Pb = $request->Pb;
            $mdp->Pc = $request->Pc;
            $mdp->Pt = $request->Pt;
            $mdp->Qa = $request->Qa;
            $mdp->Qb = $request->Qb;
            $mdp->Qc = $request->Qc;
            $mdp->Qt = $request->Qt;
            $mdp->pf = $request->pf;
            $mdp->f = $request->f;
            $mdp->save();

            return response()->json([
                "message" => "Data saved"
            ], 201);
        }
    }

    public function getMdpData()
    {
        /**
         * Retrieve the latest 500 MdpData records and return them as an array.
         *
         * @return array
         */
        $mdp = MdpData::latest()->take(500)->get()->toArray();
        return $mdp;
    }

    public function getMdpDataById($id)
    {
        /**
         * Retrieve MDP data for a given ID.
         *
         * @param int $id The ID of the MDP data to retrieve.
         * @return \Illuminate\Http\JsonResponse|array The MDP data as a JSON response or an array.
         */
        $mdp = MdpData::where('id_kwh', $id)->latest()->take(100)->get();

        if ($mdp->isEmpty() || $mdp->contains('error')) {
            return response()->json([
                "message" => "Data not found"
            ], 404);
        }

        return $mdp->toArray();
    }

    public function getMdpDataByIdLimit($id, $limit)
    {
        /**
         * Retrieve the latest MdpData records based on the given id and limit.
         *
         * @param int $id The id of the MdpData record.
         * @param int $limit The maximum number of records to retrieve.
         * @return \Illuminate\Http\JsonResponse|array The JSON response containing the MdpData records or an empty array if no records are found.
         */
        $mdp = MdpData::where('id_kwh', $id)->latest()->take($limit)->get();

        if ($mdp->isEmpty()) {
            return response()->json([
                "message" => "Data not found"
            ], 404);
        }

        return $mdp->toArray();
    }

    public function addMdpKwh(Request $request, $id)
    {
        // Memastikan data tersimpan setiap 5 menit sekali
        /**
         * Save MdpKwh data if the latest data is older than 5 minutes,
         * otherwise return an error response.
         *
         * @param  \Illuminate\Http\Request  $request
         * @return \Illuminate\Http\JsonResponse
         */
        $latestData = MdpKwh::latest('created_at')->first();

        if ($latestData) {
            $fiveMinutesAgo = Carbon::now()->subMinutes(5);
            if ($latestData->created_at < $fiveMinutesAgo) {
                $mdp = new MdpKwh;

                $mdp->kwh_1 = $request->kwh_1;
                $mdp->kwh_2 = $request->kwh_2;
                $mdp->kwh_3 = $request->kwh_3;
                $mdp->kwh_4 = $request->kwh_4;
                $mdp->kwh_5 = $request->kwh_5;
                $mdp->save();

                return response()->json([
                    "message" => "Data saved"
                ], 201);
            } else {
                return response()->json([
                    "message" => "Sorry, belum 5 menit"
                ], 400);
            }
        } else {
            // Save kalau belum ada data
            $mdp = new MdpKwh;

            $mdp->kwh_1 = $request->kwh_1;
            $mdp->kwh_2 = $request->kwh_2;
            $mdp->kwh_3 = $request->kwh_3;
            $mdp->kwh_4 = $request->kwh_4;
            $mdp->kwh_5 = $request->kwh_5;
            $mdp->save();

            return response()->json([
                "message" => "Data saved"
            ], 201);
        }
    }

    public function getMdpKwh()
    {
        /**
         * Retrieve the latest 500 MdpKwh records.
         *
         * @return array
         */
        $mdp = MdpKwh::latest()->take(500)->get()->toArray();
        return $mdp;
    }

    public function getMdpKwhById($id)
    {
        /**
         * Retrieve the latest 100 records of a specific MdpKwh instance.
         *
         * @param int $id The ID of the MdpKwh instance.
         * @return \Illuminate\Http\JsonResponse|array The JSON response containing the latest 100 records of the MdpKwh instance, or an empty array if no records are found.
         */
        $mdp = MdpKwh::latest()->take(100)->get('kwh_' . $id);

        if ($mdp->isEmpty()) {
            return response()->json([
                "message" => "Data not found"
            ], 404);
        }

        return $mdp->toArray();
    }

    public function getMdpKwhByIdLimit($id, $limit)
    {
        /**
         * Retrieve the latest MdpKwh records for a given id and limit.
         *
         * @param int $id The id of the MdpKwh record.
         * @param int $limit The maximum number of records to retrieve.
         * @return \Illuminate\Http\JsonResponse|array The JSON response containing the MdpKwh records or an empty array if no records are found.
         */
        $mdp = MdpKwh::where('id_kwh', $id)->latest()->take($limit)->get();

        if ($mdp->isEmpty()) {
            return response()->json([
                "message" => "Data not found"
            ], 404);
        }

        return $mdp->toArray();
    }

    public function totalMdpKwhToday()
    {
        /**
         * Retrieve the total energy consumption for today.
         *
         * @return \Illuminate\Http\JsonResponse|array The total energy consumption for today.
         */
        $today = Carbon::today();
        $yesterday = Carbon::yesterday();

        $energyToday = DB::transaction(function () use ($today, $yesterday) {
            // Subquery for today's latest record
            $todayData = MdpKwh::whereDate('created_at', $today)
                ->latest()
                ->first();

            // Subquery for yesterday's latest record
            $yesterdayData = MdpKwh::whereDate('created_at', $yesterday)
                ->latest()
                ->first();

            if ($todayData && $yesterdayData) {
                // Calculate the difference
                return [
                    'kwh_1' => $todayData->kwh_1 - $yesterdayData->kwh_1,
                    'kwh_2' => $todayData->kwh_2 - $yesterdayData->kwh_2,
                    'kwh_3' => $todayData->kwh_3 - $yesterdayData->kwh_3,
                    'kwh_4' => $todayData->kwh_4 - $yesterdayData->kwh_4,
                    'kwh_5' => $todayData->kwh_5 - $yesterdayData->kwh_5,
                ];
            }

            return null;
        });
        $todayKwh = number_format(array_sum($energyToday) / 1000, 2, ',', '.');

        return $todayKwh;
    }
}
