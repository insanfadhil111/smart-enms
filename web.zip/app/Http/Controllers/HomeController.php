<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\PvController;
use App\Http\Controllers\MdpController;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $MdpCon = new MdpController();
        $todayKwh = $MdpCon->totalMdpKwhToday();
        $PvCon = new PvController();
        $todayMpp = $PvCon->mppTodayGeneration();
        $todayMppGenerated = number_format($todayMpp, 2, ',', '.');
        $todayGw = $PvCon->gwTodayGeneration();
        $todayGwGenerated = number_format($todayGw, 2, ',', '.');

        $todayPv = $todayMpp + $todayGw;
        $todayIncome = number_format($todayPv * 1440, 0, ',', '.');


        return view('pages.dashboard', compact('todayKwh', 'todayMppGenerated', 'todayGwGenerated', 'todayIncome'));
    }
}
